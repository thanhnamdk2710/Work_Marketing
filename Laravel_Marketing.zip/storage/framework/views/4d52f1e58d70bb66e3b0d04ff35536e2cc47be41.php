<?php $__env->startSection('content'); ?>
<ul class="breadcrumb">
    <li>
        <i class="icon-home"></i>
        <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
        <i class="icon-angle-right"></i> 
    </li>
    <li>
        <i class="icon-home"></i>
        <a href="<?php echo e(route('brands.index')); ?>">Brands</a>
        <i class="icon-angle-right"></i>
    </li>
    <li>
        <i class="icon-edit"></i>
        <span>Edit Brand</span>
    </li>
</ul>
<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header" data-original-title>
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Edit Brand</h2>
        </div>
        <div class="box-content">
            <?php echo e(Form::open(['route' => ['brands.update', $brand->id], 'method' => 'PUT', 'class' => 'form-horizontal'])); ?>

            <fieldset>
                <div class="control-group">
                    <?php echo e(Form::label('name', 'Brand Name', ['class' => 'control-label'])); ?>

                    <div class="controls">
                        <?php echo e(Form::text('name', $brand->name, ['class' => 'input-xlarge', 'placeholder' => 'Enter Brand Name'])); ?>

                    </div>
                </div>
                <div class="form-actions">
                    <?php echo e(Form::submit ('Save', ['class' => 'btn btn-primary'])); ?>

                    <?php echo e(Form::reset ('Cancel', ['class' => 'btn'])); ?>

                </div>
            </fieldset>
            <?php echo e(Form::close()); ?>

        </div>
    </div><!--/span-->
</div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>