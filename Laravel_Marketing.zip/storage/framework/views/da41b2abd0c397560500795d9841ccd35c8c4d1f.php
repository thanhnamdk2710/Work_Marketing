<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">
                        <h2>Danh mục sản phẩm</h2>
                        <div class="panel-group category-products" id="accordian">
                            <?php if(count($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title"><a href="<?php echo e(route('user.category', $category->slug)); ?>"><?php echo e($category->name); ?></a></h4>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <span>Không có danh mục nào</span>
                            <?php endif; ?>
                        </div>

                        <div class="brands_products">
                            <h2>Thương hiệu</h2>
                            <div class="brands-name">
                                <ul class="nav nav-pills nav-stacked">
                                    <?php if(count($brands)): ?>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('user.brand', $brand->slug)); ?>">
                                                    <span class="pull-right">
                                                        (<?php echo e(count($brand->products)); ?>)
                                                    </span><?php echo e($brand->slug); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span>Chưa có thương hiệu nào</span>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-9 padding-right">
                    <div class="blog-post-area">
                        <h2 class="title text-center">Bài viết mới</h2>
                        <?php if(count($news)): ?>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-blog-post">
                                    <h3><?php echo e($new->name); ?></h3>
                                    <div class="post-meta">
                                        <ul>
                                            <li><i class="fa fa-clock-o"></i><?php echo e(date_format($new->created_at, "H:i:s")); ?></li>
                                            <li><i class="fa fa-calendar"></i><?php echo e(date_format($new->created_at, "d-m-Y")); ?></li>
                                        </ul>
                                    </div>
                                    <a href="<?php echo e(route('user.blog', $new->slug)); ?>">
                                        <img src="<?php echo e(asset($new->image)); ?>" alt="">
                                    </a>
                                    <p><?php echo $new->description; ?></p>
                                    <a  class="btn btn-primary" href="<?php echo e(route('user.blog', $new->slug)); ?>">Đọc thêm</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($news->links()); ?>

                        <?php else: ?>
                            <div class="alert alert-warning">
                                Chưa có bài viết nào
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>