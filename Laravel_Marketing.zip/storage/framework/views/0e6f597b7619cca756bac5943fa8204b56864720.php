<?php $__env->startSection('title'); ?>
    Home || <?php echo e(Session::get('shop')->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="slider">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-target="#slider-carousel" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($key == 0 ? 'active' : ''); ?>"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>

                        <div class="carousel-inner">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e($key == 0 ? 'item active' : 'item'); ?>">
                                    <img src="<?php echo e(asset($slider->image)); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">
                        <h2>Danh danh sản phẩm</h2>
                        <div class="panel-group category-products" id="accordian">
                            <?php if(count($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a href="<?php echo e(route('user.category', $category->slug)); ?>"><?php echo e($category->name); ?></a>
                                            </h4>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <span>Chưa có danh mục nào</span>
                            <?php endif; ?>
                        </div>

                        <div class="brands_products">
                            <h2>Thương hiệu</h2>
                            <div class="brands-name">
                                <ul class="nav nav-pills nav-stacked">
                                    <?php if(count($brands)): ?>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('user.brand', $brand->slug)); ?>">
                                                    <span class="pull-right">
                                                        (<?php echo e(count($brand->products)); ?>)
                                                    </span><?php echo e($brand->slug); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span>Chưa có thương hiệu nào</span>
                                    <?php endif; ?>

                                </ul>
                            </div>
                        </div>

                        <div class="shipping text-center">
                            <img src="<?php echo e(asset('frontend/images/home/shipping.jpg')); ?>" alt="" />
                        </div>
                    </div>
                </div>

                <div class="col-sm-9 padding-right">
                    <div class="features_items">
                        <h2 class="title text-center">Sản phẩm mới</h2>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4">
                            <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <img src="<?php echo e(asset($product->image)); ?>" alt="" />
                                        <h2><?php echo e($product->price); ?> VNĐ</h2>
                                        <p><?php echo e($product->name); ?></p>
                                        <a href="<?php echo e(route('user.product', $product->slug)); ?>" class="btn btn-default add-to-cart">
                                            <i class="fa fa-shopping-cart"></i>Chi tiết
                                        </a>
                                    </div>
                                    <div class="product-overlay">
                                        <div class="overlay-content">
                                            <h2><?php echo e($product->price); ?> VNĐ</h2>
                                            <p><?php echo e($product->name); ?></p>
                                            <a href="<?php echo e(route('user.product', $product->slug)); ?>" class="btn btn-default add-to-cart">
                                                <i class="fa fa-shopping-cart"></i>Chi tiết
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="recommended_items">
                        <h2 class="title text-center">Sản phẩm đề xuất</h2>
                        <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <?php for($i = 0; $i < count($recomment_products); $i += 3): ?>
                                    <div class="item <?php echo e($i == 0 ? 'active' : ''); ?>">
                                        <?php for($j = 0; $j < 3; $j++): ?>
                                            <div class="col-sm-4">
                                                <div class="product-image-wrapper">
                                                    <div class="single-products">
                                                        <div class="productinfo text-center">
                                                            <img src="<?php echo e(asset($recomment_products[$i + $j]->image)); ?>" alt="" />
                                                            <h2><?php echo e($recomment_products[$i + $j]->price); ?> VNĐ</h2>
                                                            <p><?php echo e($recomment_products[$i + $j]->name); ?></p>
                                                            <a href="<?php echo e(route('user.product', $recomment_products[$i + $j]->slug)); ?>" class="btn btn-default add-to-cart">
                                                                <i class="fa fa-shopping-cart"></i>Chi tiết
                                                            </a>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>