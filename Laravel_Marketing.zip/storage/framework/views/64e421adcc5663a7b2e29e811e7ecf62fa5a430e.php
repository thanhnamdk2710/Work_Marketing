<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li>
            <i class="icon-home"></i>
            <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
            <i class="icon-angle-right"></i>
        </li>
        <li><span>Brands</span></li>
    </ul>
    <div class="row-fluid sortable">
        <div class="box span12">
            <div class="box-header" data-original-title>
                <h2><i class="halflings-icon user"></i><span class="break"></span>List Brands</h2>
            </div>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Well done!</strong> <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <div class="box-content">
                <?php if(count($brands)): ?>
                    <table class="table table-striped table-bordered bootstrap-datatable">
                        <thead>
                        <tr>
                            <th>#ID</th>
                            <th>Brand Name</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td class="center"><?php echo e($brand->name); ?></td>
                                <td class="center">
                                    <?php if($brand->status): ?>
                                        <span class="label label-success">Active</span>
                                    <?php else: ?>
                                        <span class="label label-important">Unactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="center">
                                    <?php if($brand->status): ?>
                                        <a class="btn btn-danger"
                                           href="<?php echo e(route('brands.status', $brand->id)); ?>">
                                            <i class="halflings-icon white thumbs-down"></i>
                                        </a>
                                    <?php else: ?>
                                        <a class="btn btn-success"
                                           href="<?php echo e(route('brands.status', $brand->id)); ?>">
                                            <i class="halflings-icon white thumbs-up"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a class="btn btn-info" href="<?php echo e(route('brands.edit', $brand->id)); ?>">
                                        <i class="halflings-icon white edit"></i>
                                    </a>

                                    <?php echo e(Form::open(['route' => ['brands.destroy', $brand->id], 'method' => 'DELETE', 'class' => 'form-inline'])); ?>

                                        <?php echo e(Form::button(
                                            '<i class="halflings-icon white trash"></i>',
                                            ['type' => 'submit', 'class' => 'btn btn-danger']
                                        )); ?>

                                    <?php echo e(Form::close()); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-block ">
                        <strong>Warning!</strong> Brand not found!
                    </div>
                <?php endif; ?>
            </div>
        </div><!--/span-->
    </div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>