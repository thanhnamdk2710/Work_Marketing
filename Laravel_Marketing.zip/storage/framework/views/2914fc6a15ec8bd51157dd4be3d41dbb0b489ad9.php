<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">
                        <h2>Danh mục sản phẩm</h2>
                        <div class="panel-group category-products" id="accordian">
                            <?php if(count($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a href="<?php echo e(route('user.category', $list_category->slug)); ?>">
                                                    <?php echo e($list_category->name); ?>

                                                </a>
                                            </h4>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <span>Chưa có danh mục nào</span>
                            <?php endif; ?>
                        </div>

                        <div class="brands_products">
                            <h2>Thương hiệu</h2>
                            <div class="brands-name">
                                <ul class="nav nav-pills nav-stacked">
                                    <?php if(count($brands)): ?>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('user.brand', $list_brand->slug)); ?>">
                                                    <span class="pull-right">
                                                        (<?php echo e(count($list_brand->products)); ?>)
                                                    </span><?php echo e($list_brand->slug); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span>Chưa có thương hiệu nào</span>
                                    <?php endif; ?>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-9 padding-right">
                    <div class="product-details">
                        <div class="col-sm-5">
                            <div class="view-product">
                                <img src="<?php echo e(asset($product->image)); ?>" alt="" />
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="product-information">
                                <h2><?php echo e($product->name); ?></h2>
                                <span>
									<span><?php echo e($product->price); ?> VNĐ</span>
								</span>
                                <p><b>Danh mục: </b> <?php echo e($product->category->name); ?></p>
                                <p><b>Thương hiệu: </b> <?php echo e($product->brand->name); ?></p>
                                <?php
                                    $size = explode(', ', $product->size);
                                    $color = explode(', ', $product->color);
                                ?>
                                <p><b>Size: </b>
                                    <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <i class="product-size"><?php echo e($itemSize); ?></i>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                                <p><b>Color: </b>
                                    <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <i class="product-size"><?php echo e($itemColor); ?></i>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="category-tab shop-details-tab">
                        <div class="col-sm-12">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#reviews" data-toggle="tab">Chi tiết</a></li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade active in" id="reviews" >
                                <div class="col-sm-12">
                                    <?php echo $product->description; ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="recommended_items">
                        <h2 class="title text-center">Sản phẩm đề xuất</h2>
                        <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <?php for($i = 0; $i < count($recomment_products); $i += 3): ?>
                                    <div class="item <?php echo e($i == 0 ? 'active' : ''); ?>">
                                        <?php for($j = 0; $j < 3; $j++): ?>
                                            <div class="col-sm-4">
                                                <div class="product-image-wrapper">
                                                    <div class="single-products">
                                                        <div class="productinfo text-center">
                                                            <img src="<?php echo e(asset($recomment_products[$i + $j]->image)); ?>" alt="" />
                                                            <h2><?php echo e($recomment_products[$i + $j]->price); ?> VNĐ</h2>
                                                            <p><?php echo e($recomment_products[$i + $j]->name); ?></p>
                                                            <a href="<?php echo e(route('user.product', $recomment_products[$i + $j]->slug)); ?>" class="btn btn-default add-to-cart">
                                                                <i class="fa fa-shopping-cart"></i>Chi tiết
                                                            </a>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>